-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.5.18


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema courier_administration
--

CREATE DATABASE IF NOT EXISTS courier_administration;
USE courier_administration;

--
-- Definition of table `company_name`
--

DROP TABLE IF EXISTS `company_name`;
CREATE TABLE `company_name` (
  `ID` int(111) NOT NULL AUTO_INCREMENT,
  `source` varchar(999) NOT NULL,
  `destination` varchar(999) NOT NULL,
  `company_name` varchar(999) NOT NULL,
  `contact` varchar(999) NOT NULL,
  `addres` varchar(999) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company_name`
--

/*!40000 ALTER TABLE `company_name` DISABLE KEYS */;
INSERT INTO `company_name` (`ID`,`source`,`destination`,`company_name`,`contact`,`addres`) VALUES 
 (1,'Amravati','Nagpur','Shiv Travels','99898898','Panchavati, Amravati');
/*!40000 ALTER TABLE `company_name` ENABLE KEYS */;


--
-- Definition of table `courier_boy_entry`
--

DROP TABLE IF EXISTS `courier_boy_entry`;
CREATE TABLE `courier_boy_entry` (
  `ID` int(111) NOT NULL AUTO_INCREMENT,
  `name` varchar(999) NOT NULL,
  `contact` varchar(999) NOT NULL,
  `address` varchar(999) NOT NULL,
  `city` varchar(999) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courier_boy_entry`
--

/*!40000 ALTER TABLE `courier_boy_entry` DISABLE KEYS */;
INSERT INTO `courier_boy_entry` (`ID`,`name`,`contact`,`address`,`city`) VALUES 
 (1,'sandeshharkut','9405437427','Sarafa Amravati','Amravati');
/*!40000 ALTER TABLE `courier_boy_entry` ENABLE KEYS */;


--
-- Definition of table `courier_entry`
--

DROP TABLE IF EXISTS `courier_entry`;
CREATE TABLE `courier_entry` (
  `ID` int(111) NOT NULL AUTO_INCREMENT,
  `courier_sender_name` varchar(999) NOT NULL,
  `date` varchar(999) NOT NULL,
  `senders_contact` varchar(999) NOT NULL,
  `senders_email` varchar(999) NOT NULL,
  `senders_address` varchar(999) NOT NULL,
  `senders_city` varchar(999) NOT NULL,
  `receiver_name` varchar(999) NOT NULL,
  `receiver_address` varchar(999) NOT NULL,
  `receiver_city` varchar(999) NOT NULL,
  `courier_via` varchar(999) NOT NULL,
  `courier_price` varchar(999) NOT NULL,
  `courier_weight` varchar(999) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courier_entry`
--

/*!40000 ALTER TABLE `courier_entry` DISABLE KEYS */;
INSERT INTO `courier_entry` (`ID`,`courier_sender_name`,`date`,`senders_contact`,`senders_email`,`senders_address`,`senders_city`,`receiver_name`,`receiver_address`,`receiver_city`,`courier_via`,`courier_price`,`courier_weight`,`status`) VALUES 
 (2,'jk','2015-03-12','9898998989','kushal@gmail.com','Farshi stop amravati','Amravati','Suraj','Bardi','Nagpur','Shiv Travels','120','12 GM',1),
 (3,'jk','2015-03-12','9898998989','kushal@gmail.com','Farshi stop amravati','Amravati','Suraj','Bardi','Nagpur','Shiv Travels','120','12 GM',1),
 (4,'jk','2015-12-31','99898','kj22@jh.m','kiuikjk','ui','uiu','iujkj','iu','iu','iui','u',1),
 (5,'jk','2015-03-06','1121221','as@ad','j','jk','kjk','jk','j','1','z','12 GM',1),
 (6,'jk','2015-03-06','1121221','as@ad','j','jk','kjk','jk','j','1','z','12 GM',1),
 (7,'jk','2015-03-06','1121221','as@ad','j','jk','kjk','jk','j','1','z','12 GM',1),
 (8,'Tushar Nirmal','2015-12-31','099898989','tushar@gmail.com','Chandur Bazar Amravati','Amravati','Kushal','Farshi stop Amravati','Amravati','1','200','1.5 gram',1);
/*!40000 ALTER TABLE `courier_entry` ENABLE KEYS */;


--
-- Definition of table `ecommerce_courier_entry`
--

DROP TABLE IF EXISTS `ecommerce_courier_entry`;
CREATE TABLE `ecommerce_courier_entry` (
  `ID` int(111) NOT NULL AUTO_INCREMENT,
  `company_id` varchar(999) NOT NULL,
  `date` varchar(111) NOT NULL,
  `receiver_name` varchar(999) NOT NULL,
  `receiver_add` varchar(999) NOT NULL,
  `receiver_city` varchar(999) NOT NULL,
  `courier_via` varchar(999) NOT NULL,
  `price` varchar(999) NOT NULL,
  `status` int(111) NOT NULL,
  `boy` varchar(999) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ecommerce_courier_entry`
--

/*!40000 ALTER TABLE `ecommerce_courier_entry` DISABLE KEYS */;
INSERT INTO `ecommerce_courier_entry` (`ID`,`company_id`,`date`,`receiver_name`,`receiver_add`,`receiver_city`,`courier_via`,`price`,`status`,`boy`) VALUES 
 (1,'1','2015-04-10','Kushal','Farshi Stop','Amravati','1','1800',1,'sandeshharkut'),
 (2,'1','2015-04-07','Kushal','Sarafa','Amravati','1','1800',1,'sandeshharkut'),
 (3,'2','2015-04-08','Kushal','Sarafa ','Amravati','1','12000',1,'sandeshharkut'),
 (4,'2','2015-04-23','Kushal','sarafa','Amravati','1','1800',0,'0');
/*!40000 ALTER TABLE `ecommerce_courier_entry` ENABLE KEYS */;


--
-- Definition of table `ecommerce_entry`
--

DROP TABLE IF EXISTS `ecommerce_entry`;
CREATE TABLE `ecommerce_entry` (
  `ID` int(111) NOT NULL AUTO_INCREMENT,
  `Company_Name` varchar(999) NOT NULL,
  `contact` varchar(999) NOT NULL,
  `email` varchar(999) NOT NULL,
  `address` varchar(999) NOT NULL,
  `city` varchar(999) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ecommerce_entry`
--

/*!40000 ALTER TABLE `ecommerce_entry` DISABLE KEYS */;
INSERT INTO `ecommerce_entry` (`ID`,`Company_Name`,`contact`,`email`,`address`,`city`) VALUES 
 (1,'MH27 Solutions','9890546711','mh27@gmail.com','Shankar Nagar Amravati','Amravati'),
 (2,'Flipkart.com','989899989898','flipkart@hotmail.com','MG Road,','Banglore');
/*!40000 ALTER TABLE `ecommerce_entry` ENABLE KEYS */;


--
-- Definition of table `salary`
--

DROP TABLE IF EXISTS `salary`;
CREATE TABLE `salary` (
  `ID` int(111) NOT NULL AUTO_INCREMENT,
  `name` varchar(999) NOT NULL,
  `salary` varchar(999) NOT NULL,
  `month` varchar(999) NOT NULL,
  `year` varchar(999) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salary`
--

/*!40000 ALTER TABLE `salary` DISABLE KEYS */;
INSERT INTO `salary` (`ID`,`name`,`salary`,`month`,`year`) VALUES 
 (1,'Ashwini Raut','12000','March','2015'),
 (2,'Kushal ii','12000','January','2025'),
 (3,'Ashwini Raut','12000','January','2015');
/*!40000 ALTER TABLE `salary` ENABLE KEYS */;


--
-- Definition of table `staff_presenty`
--

DROP TABLE IF EXISTS `staff_presenty`;
CREATE TABLE `staff_presenty` (
  `ID` int(111) NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(999) NOT NULL,
  `date` varchar(999) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff_presenty`
--

/*!40000 ALTER TABLE `staff_presenty` DISABLE KEYS */;
INSERT INTO `staff_presenty` (`ID`,`staff_id`,`date`) VALUES 
 (1,'7','2015-04-06'),
 (2,'7','2015-04-15'),
 (3,'11','2015-04-28'),
 (4,'7','2015-04-05'),
 (5,'3','2015-04-02'),
 (6,'3','2015-04-03'),
 (7,'4','2015-04-07');
/*!40000 ALTER TABLE `staff_presenty` ENABLE KEYS */;


--
-- Definition of table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `ID` int(111) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(999) NOT NULL,
  `last_name` varchar(999) NOT NULL,
  `email` varchar(111) NOT NULL,
  `password` varchar(999) NOT NULL,
  `contact` varchar(999) NOT NULL,
  `address` varchar(999) NOT NULL,
  `Courier_entry` varchar(999) NOT NULL,
  `track_courier` varchar(999) NOT NULL,
  `deliver_courier` varchar(999) NOT NULL,
  `ecommerce` varchar(999) NOT NULL,
  `staff_management` varchar(999) NOT NULL,
  `staff_registration` varchar(999) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`ID`,`first_name`,`last_name`,`email`,`password`,`contact`,`address`,`Courier_entry`,`track_courier`,`deliver_courier`,`ecommerce`,`staff_management`,`staff_registration`) VALUES 
 (3,'Kushal','Dhole','admin@gmail.com','admin','9405437427',' At Sidhanapur, Post Vadura, Taluka Nandgaon Khandeshawar, Dist Amravati.','','','','','',''),
 (4,'Kushal','Dhole','kush@gmail.com','kush','98989999','Farshi Stop Amravati','courier_entry','track_courier','null','null','staff_management','staff_registration'),
 (7,'Kushal','ii','kkk@gmail.com','kkk','22323223',' At Sidhanapur, Post Vadura, Taluka Nandgaon Khandeshawar, Dist Amravati.','courier_entry','track_courier','null','null','staff_management','null'),
 (9,'Kushal','Dhole','kushall@gmail.com','kushall','98989989','Farshi Stop Amravati','1','1','null','1','null','null'),
 (10,'Tushar ','Nirmal','tushar@gmail.com','tushar','9890546711','33, Pooja Colony Amravati','1','1','1','1','1','1'),
 (11,'Kushal','ii','tushar11@gmail.com','tushar11','98988989','Farshi Stop Amravati','null','null','null','null','1','1'),
 (12,'Sampada','Tikekar','sampada@gmail.com','sampada','98988898989988','Farshi Stop Amravati','1','1','null','null','1','1'),
 (13,'Ashwini','Raut','ashwini@gmail.com','ashwini','89998989989','FArshi stop amravati','null','null','null','null','null','1'),
 (14,'pa','Dhole','pa@gmail.com','kushal','989898989','33, Pooja Colony Amravati','1','1','null','null','null','1');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
